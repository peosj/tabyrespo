<?php include("../../config/config.php"); ?>
<?php
session_start();
$user_id = $_POST['user_id'];
if(isset($_POST['submit']))
{
    
    $fname = $_POST['fname'];             
    $lname = $_POST['lname'];
    $company_name = $_POST['cname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address']; 
    $business_type = $_POST['busines_type'];
    $billing_cycle = $_POST['billing_cycle'];
    $bank_name = $_POST['bank_name'];
    $bank_address = $_POST['bank_address'];
    $name_on_bank_account = $_POST['name_on_account'];
    $ifsc_code = $_POST['ifsc_code'];
    $swift_code = $_POST['swift_code'];
    $date = date('Y-m-d');
                
      echo  $query = "UPDATE users set f_name = '".$fname."', l_name = '".$lname."', company_name = '".$company_name."', email = '".$email."', contact_number = '".$phone."',address = '".$address."', business_type = '".$business_type."',billing_cycle = '".$billing_cycle."',bank_name = '".$bank_name."',bank_address = '".$bank_address."',name_on_bank_account = '".$name_on_bank_account."',ifsc_code = '".$ifsc_code."',swift_code = '".$swift_code."',date = '".$date."' where user_id = $user_id";
        //exit;
        
        $r1 = mysql_query($query);
        
        echo $query;
        //exit;     
/*    
$path = "../ajax/profile/user";
if ( ! is_dir($path)) 
    {
        mkdir($path);
    }

if ($_FILES["file"]["error"] > 0)
   {
        echo "Apologies, an error has occurred.";
        echo "Error Code: " . $_FILES["file"]["error"];
   }
else
   {
        move_uploaded_file($_FILES["file"]["tmp_name"],
        $path."/profile_pic_" .$login_id.".png");
    }*/

        //exit;    
    header("location:../../profile.php?msg=success");        
}
else
{
    header("location:../../profile.php?msg=error");
}

?>