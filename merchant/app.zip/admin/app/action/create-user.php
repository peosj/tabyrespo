<?php include("../../../config/config.php"); ?>
<?php
session_start();
//$login_id = $_SESSION['logid'];
if(isset($_POST['submit']))
{
    
    $fname = $_POST['fname'];             
    $lname = $_POST['lname'];
    $company_name = $_POST['cname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address']; 
    $business_type = $_POST['business_type'];
    $account_number = $_POST['account_number'];
    $password = $_POST['password'];
    $billing_cycle = $_POST['billing_cycle'];
    $bank_name = $_POST['bank_name'];
    $bank_address = $_POST['bank_address'];
    $name_on_bank_account = $_POST['name_on_bank'];
    $ifsc_code = $_POST['ifsc_code'];
    $swift_code = $_POST['swift_code'];
    $dba = $_POST['dba'];
    $website = $_POST['website'];
    $commision = $_POST['commision'];
    $date = date('Y-m-d');
    
    
                
        $query = "insert into users (user_type,f_name, l_name, company_name, email, contact_number,address, business_type, password,billing_cycle,bank_name,account_number,bank_address,name_on_bank_account,ifsc_code,swift_code,dba,website,date,status,comission) values('user','".$fname."', '".$lname."', '".$company_name."', '".$email."', '".$phone."','".$address."', '".$business_type."','".$password."','".$billing_cycle."','".$bank_name."','".$account_number."','".$bank_address."','".$name_on_bank_account."','".$ifsc_code."','".$swift_code."','".$dba."','".$website."','".$date."','1','".$commision."')";
        
        $r1 = mysql_query($query);
        $login_id = mysql_insert_id();
         //$query;
        //exit;     
        if($r1)
        {
            $query_balance = "insert into balance (balance,reserved_balance,total,withdrawal_request,user_id) values('0','0','0','0','".$login_id."')";
            $balance_query = mysql_query($query_balance);
             
        }
    
$path = "../ajax/profile/user";
if ( ! is_dir($path)) 
    {
        mkdir($path);
    }

if ($_FILES["file"]["error"] > 0)
   {
        echo "Apologies, an error has occurred.";
        echo "Error Code: " . $_FILES["file"]["error"];
   }
else
   {
        move_uploaded_file($_FILES["file"]["tmp_name"],
        $path."/profile_pic_" .$login_id.".png");
    }

        //exit;    
    header("location:../../create-user.php?msg=success");        
}
else
{
    header("location:../../create-user.php?msg=error");
}

?>