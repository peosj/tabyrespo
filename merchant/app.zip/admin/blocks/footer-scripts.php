<script src="./../theme/libs/jquery/jquery/dist/jquery.js"></script>
<script src="./../theme/libs/jquery/bootstrap/dist/js/bootstrap.js"></script>
<script src="./../theme/html/js/ui-load.js"></script>
<script src="./../theme/html/js/ui-jp.config.js"></script>
<script src="./../theme/html/js/ui-jp.js"></script>
<script src="./../theme/html/js/ui-nav.js"></script>
<script src="./../theme/html/js/ui-toggle.js"></script>
<script src="./../theme/html/js/ui-client.js"></script>