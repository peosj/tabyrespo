module.exports = {
  html:{
    src:[
      'html/js/app.src.js'
    ],
    dest:'html/js/app.min.js'
  }
}
