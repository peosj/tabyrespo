  <link rel="stylesheet" href="./theme/libs/assets/animate.css/animate.css" type="text/css" />
  <link rel="stylesheet" href="./theme/libs/assets/font-awesome/css/font-awesome.min.css" type="text/css" />
  <link rel="stylesheet" href="./theme/libs/assets/simple-line-icons/css/simple-line-icons.css" type="text/css" />
  <link rel="stylesheet" href="./theme/libs/jquery/bootstrap/dist/css/bootstrap.css" type="text/css" />
  <link rel="stylesheet" href="./theme/html/css/font.css" type="text/css" />
  <link rel="stylesheet" href="./theme/html/css/app.css" type="text/css" />