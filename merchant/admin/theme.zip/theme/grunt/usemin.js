module.exports = {
  html: ['angular/index.html','angular/material.html'],
  options: {
    dest: 'angular'
  }
}
