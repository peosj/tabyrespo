<?php

date_default_timezone_set("Asia/Kolkata");

date_default_timezone_set("Asia/Kolkata");
$con = mysql_connect("localhost", "qykpay", "qykpay");
$db = mysql_select_db("qykpay11_qykpay", $con);

//$conn = new mysqli("localhost", "qykpay11_qykpay", "Qykpay@11", "qykpay11_qykpay");
    //if ($conn->connect_errno) {
        //echo "Failed to connect to MySQL: " . $conn->connect_error;
    //}
?>
